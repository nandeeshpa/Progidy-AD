package com.example.tictactoe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button[] buttons = new Button[9];
    private boolean isXTurn = true;
    private int[] board = new int[9]; // 0 = empty, 1 = X, 2 = O
    private TextView statusTextView;
    private boolean gameActive = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusTextView = findViewById(R.id.statusTextView);

        // Initialize buttons
        for (int i = 0; i < 9; i++) {
            String buttonID = "button" + i;
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
            buttons[i] = findViewById(resID);
            final int index = i;
            buttons[i].setOnClickListener(v -> onCellClicked(index));
        }

        findViewById(R.id.resetButton).setOnClickListener(v -> resetGame());
    }

    private void onCellClicked(int index) {
        if (!gameActive || board[index] != 0) return;

        board[index] = isXTurn ? 1 : 2;
        buttons[index].setText(isXTurn ? "X" : "O");

        if (checkWinner()) {
            statusTextView.setText("Player " + (isXTurn ? "X" : "O") + " Wins!");
            gameActive = false;
        } else if (isDraw()) {
            statusTextView.setText("It's a Draw!");
            gameActive = false;
        } else {
            isXTurn = !isXTurn;
            statusTextView.setText("Player " + (isXTurn ? "X" : "O") + "'s Turn");
        }
    }

    private boolean checkWinner() {
        int[][] winPositions = {
                {0,1,2},{3,4,5},{6,7,8}, // rows
                {0,3,6},{1,4,7},{2,5,8}, // cols
                {0,4,8},{2,4,6}          // diagonals
        };
        for (int[] pos : winPositions) {
            if (board[pos[0]] != 0 &&
                    board[pos[0]] == board[pos[1]] &&
                    board[pos[1]] == board[pos[2]]) {
                return true;
            }
        }
        return false;
    }

    private boolean isDraw() {
        for (int cell : board) {
            if (cell == 0) return false;
        }
        return true;
    }

    private void resetGame() {
        isXTurn = true;
        gameActive = true;
        for (int i = 0; i < 9; i++) {
            board[i] = 0;
            buttons[i].setText("");
        }
        statusTextView.setText("Player X's Turn");
    }
}
