package com.example.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textViewTimer;
    private Button btnStart, btnPause, btnReset;

    private Handler handler = new Handler();
    private long startTime = 0L;
    private long timeBuff = 0L;
    private long updateTime = 0L;
    private boolean isRunning = false;

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            long millisecondTime = System.currentTimeMillis() - startTime;
            updateTime = timeBuff + millisecondTime;

            int secs = (int) (updateTime / 1000);
            int mins = secs / 60;
            secs = secs % 60;
            int millis = (int) (updateTime % 1000);

            textViewTimer.setText(String.format("%02d:%02d:%03d", mins, secs, millis));
            handler.postDelayed(this, 10);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewTimer = findViewById(R.id.textViewTimer);
        btnStart = findViewById(R.id.btnStart);
        btnPause = findViewById(R.id.btnPause);
        btnReset = findViewById(R.id.btnReset);

        btnStart.setOnClickListener(v -> {
            if (!isRunning) {
                startTime = System.currentTimeMillis();
                handler.postDelayed(runnable, 0);
                isRunning = true;
            }
        });

        btnPause.setOnClickListener(v -> {
            if (isRunning) {
                timeBuff += System.currentTimeMillis() - startTime;
                handler.removeCallbacks(runnable);
                isRunning = false;
            }
        });

        btnReset.setOnClickListener(v -> {
            handler.removeCallbacks(runnable);
            startTime = 0L;
            timeBuff = 0L;
            updateTime = 0L;
            isRunning = false;
            textViewTimer.setText("00:00:000");
        });
    }
}
